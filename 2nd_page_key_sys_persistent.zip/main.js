const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d', { alpha: false });

let DPR = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
let width = 0, height = 0;

function resize() {
  DPR = Math.max(1, Math.min(2, window.devicePixelRatio || 1));
  width = Math.floor(window.innerWidth);
  height = Math.floor(window.innerHeight);
  canvas.width = Math.floor(width * DPR);
  canvas.height = Math.floor(height * DPR);
  canvas.style.width = width + 'px';
  canvas.style.height = height + 'px';
  ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
}
window.addEventListener('resize', resize, { passive: true });
resize();

/* Particle system */
const PARTICLE_COUNT = Math.round((width * height) / 40000) || 80;
const particles = [];

function rand(min, max) { return Math.random() * (max - min) + min; }

class Particle {
  constructor() {
    this.reset(true);
  }
  reset(initial=false) {
    this.x = rand(0, width);
    this.y = initial ? rand(-height, height) : rand(-50, -10);
    this.vy = rand(20, 120); // speed in px/sec
    this.size = rand(0.6, 3.2);
    this.alpha = rand(0.2, 0.95);
    this.sway = rand(10, 80);
    this.phase = rand(0, Math.PI * 2);
    this.twinkleRate = rand(0.5, 1.8);
    this.h = rand(0, 1);
  }
  update(dt, time, mx, my) {
    // vertical movement
    this.y += this.vy * dt;
    // horizontal gentle oscillation + parallax from mouse
    const swayX = Math.sin(this.phase + time * 0.001 * this.sway) * (this.sway * 0.02);
    const px = (mx - width * 0.5) * (0.0006 + this.size * 0.0008);
    const py = (my - height * 0.5) * (0.0003 + this.size * 0.0005);
    this.x += swayX + px;
    this.y += py;

    // twinkle
    this.h += dt * this.twinkleRate;
    const tw = 0.5 + Math.sin(this.h * Math.PI * 2) * 0.5;
    this.currentAlpha = this.alpha * (0.65 + tw * 0.7);

    if (this.y - this.size > height + 50 || this.x < -100 || this.x > width + 100) {
      this.reset(false);
    }
  }
  draw(ctx) {
    ctx.globalAlpha = Math.max(0, Math.min(1, this.currentAlpha));
    const r = this.size;
    // subtle radial gradient for nicer appearance
    const g = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, r * 4);
    g.addColorStop(0, 'rgba(255,255,255,1)');
    g.addColorStop(0.3, 'rgba(255,255,255,0.6)');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(this.x, this.y, r * 2.2, 0, Math.PI * 2);
    ctx.fill();
  }
}

function rebuildParticles() {
  particles.length = 0;
  const count = Math.max(60, Math.round((width * height) / 40000));
  for (let i = 0; i < count; i++) particles.push(new Particle());
}
rebuildParticles();

/* Mouse / touch parallax */
let mx = width / 2, my = height / 2;
function onMove(e) {
  if (e.touches && e.touches[0]) {
    mx = e.touches[0].clientX;
    my = e.touches[0].clientY;
  } else {
    mx = e.clientX;
    my = e.clientY;
  }
}
window.addEventListener('mousemove', onMove, { passive: true });
window.addEventListener('touchmove', onMove, { passive: true });

/* GUI logic */
const outputEl = document.getElementById('output');
const genBtn = document.getElementById('generate');
const copyBtn = document.getElementById('copy');
let generated = null;
function makeRandom(len=10){
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  let s=''; for(let i=0;i<len;i++) s+=chars[Math.floor(Math.random()*chars.length)]; return s;
}
genBtn.addEventListener('click', ()=>{ if (generated) return; generated = makeRandom(10); outputEl.textContent = generated; genBtn.disabled = true; copyBtn.disabled = false; });
copyBtn.addEventListener('click', async ()=>{ if(!generated) return; try{ await navigator.clipboard.writeText(generated); copyBtn.textContent='Copied'; setTimeout(()=>copyBtn.textContent='Copy',1200);}catch(e){/* ignore */} });

/* Animation loop */
let last = performance.now();
function frame(t) {
  const dt = Math.min(0.04, (t - last) / 1000);
  last = t;

  // clear
  ctx.fillStyle = '#000';
  ctx.fillRect(0, 0, width, height);

  // subtle background noise (very faint)
  // ... keep simple to maintain performance ...

  // update & draw
  for (let i = 0; i < particles.length; i++) {
    particles[i].update(dt, t, mx, my);
    particles[i].draw(ctx);
  }

  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

/* Keep particle density on resize */
let resizeObserverTimer = null;
window.addEventListener('resize', () => {
  clearTimeout(resizeObserverTimer);
  resizeObserverTimer = setTimeout(() => {
    resize();
    rebuildParticles();
  }, 120);
});
/* --- Persistent key generation with localStorage --- */
const LS_KEY_FLAG = 'myapp_generated_flag';
const LS_KEY_VALUE = 'myapp_generated_value';
const LS_KEY_TIME  = 'myapp_generated_time';

function makeRandom(len = 10) {
  const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789';
  let s = '';
  for (let i = 0; i < len; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

const genBtn  = document.getElementById('genBtn');
const copyBtn = document.getElementById('copyBtn');
const outEl   = document.getElementById('output') || document.getElementById('code');

function showCode(code) {
  if (!outEl) return;
  if (outEl.tagName === 'INPUT' || outEl.tagName === 'TEXTAREA') outEl.value = code;
  else outEl.textContent = code;
}

function setGenerated(code) {
  localStorage.setItem(LS_KEY_FLAG, '1');
  localStorage.setItem(LS_KEY_VALUE, code);
  localStorage.setItem(LS_KEY_TIME, (new Date()).toISOString());
  if (genBtn) genBtn.disabled = true;
  if (copyBtn) copyBtn.disabled = false;
  showCode(code);
}

function clearGenerated() {
  localStorage.removeItem(LS_KEY_FLAG);
  localStorage.removeItem(LS_KEY_VALUE);
  localStorage.removeItem(LS_KEY_TIME);
  if (genBtn) genBtn.disabled = false;
  if (copyBtn) copyBtn.disabled = true;
  showCode('');
}

function initPersistentGen() {
  try {
    const flag = localStorage.getItem(LS_KEY_FLAG);
    const code = localStorage.getItem(LS_KEY_VALUE);
    if (flag === '1' && code) {
      if (genBtn) genBtn.disabled = true;
      if (copyBtn) copyBtn.disabled = false;
      showCode(code);
    } else {
      if (genBtn) genBtn.disabled = false;
      if (copyBtn) copyBtn.disabled = true;
    }
  } catch (e) {
    console.error('localStorage not available', e);
  }
}

if (genBtn) {
  genBtn.addEventListener('click', (e) => {
    e.preventDefault();
    if (localStorage.getItem(LS_KEY_FLAG) === '1') {
      const existing = localStorage.getItem(LS_KEY_VALUE) || '';
      showCode(existing);
      genBtn.disabled = true;
      return;
    }
    const code = makeRandom(10);
    setGenerated(code);
  });
}

if (copyBtn) {
  copyBtn.addEventListener('click', async (e) => {
    const code = localStorage.getItem(LS_KEY_VALUE) || (outEl && (outEl.value || outEl.textContent));
    if (!code) return;
    try {
      await navigator.clipboard.writeText(code);
      const prev = copyBtn.textContent;
      copyBtn.textContent = 'Copied!';
      setTimeout(()=> copyBtn.textContent = prev, 1200);
    } catch (err) {
      console.error('Copy failed', err);
    }
  });
}

document.addEventListener('DOMContentLoaded', initPersistentGen);
window.clearGenerated = clearGenerated;
